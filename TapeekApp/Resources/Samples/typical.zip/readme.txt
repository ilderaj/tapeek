Tapeek sample
